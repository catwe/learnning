
class User(object):
	def __init__(self, name, idCard, phone, card):
		self.name = name
		self.idCard = idCard
		self.phone = phone
		self.card = card
